#include <stdio.h>
#include "adjacency_matrix.h"

int main()
{
    int n;      // Número de vértices do grafo
    int m;      // Número de arestas do grafo
    int u;   //
    int v;   //
    int q;      // Número de operações a serem executadas
    int q1;     // Operação a ser realizada
    int v1, v2;

    scanf("%d", &n);
    scanf("%d", &m);

    AdjMatrix *mat = create_graph(n);

    for (int i = 0; i < m; i++) // Recebe vértices conecctados a cada aresta
    {
        scanf(" %d", &u);
        scanf(" %d", &v);
        insert_edge(mat, u, v);
    }

    scanf("%d", &q);

    for (int i = 0; i < q; i++)
    {
        scanf(" %d", &q1);

        if (q1 == 3)
        {
            show_adjacency_matrix(mat);
            continue;
        }

        scanf(" %d", &v1);
        scanf(" %d", &v2);

        if (q1 == 1)
            insert_edge(mat, v1, v2);
        else if (q1 == 2)
            remove_edge(mat, v1, v2);
    }

    delete_graph(mat);

    return 0;
}